package com.example.footprintregulator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class Homepage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage)
    }

    fun pageOne(view: View)
    {
        Toast.makeText(this, "Start button was clicked", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, Firstpage::class.java)
        startActivity(intent)
    }

    fun openAboutMe(view: View)
    {
        val intent = Intent(this, Aboutmyself::class.java)
        startActivity(intent)
    }
}
package com.example.footprintregulator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Aboutmyself : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aboutmyself)
    }
}